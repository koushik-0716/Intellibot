from flask import Flask, render_template, request
import difflib
import json
import math
import os
import re
import ast
import operator

import google.generativeai as genai

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MEMORY_FILE = os.path.join(BASE_DIR, "memory.json")
session_started = False

# =========================
# AI SETUP
# =========================
# Recommended: set GEMINI_API_KEY in your system environment instead of keeping
# the key inside source code.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") or "AIzaSyALD0q386ZmW_wR_lJP5XbeSBppXONUCac"
MODEL_NAMES = [
    os.getenv("GEMINI_MODEL", "gemini-2.0-flash-lite"),
    "gemini-flash-lite-latest",
    "gemini-2.0-flash",
    "gemini-2.5-flash",
]
models = []

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    models = [genai.GenerativeModel(name) for name in dict.fromkeys(MODEL_NAMES)]

# =========================
# LOAD MEMORY
# =========================
try:
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        memory = json.load(f)
except (FileNotFoundError, json.JSONDecodeError):
    memory = {}

memory = {str(key).strip().lower(): value for key, value in memory.items()}


def save_memory():
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(memory, f, ensure_ascii=False, indent=4)


# =========================
# TEXT HELPERS
# =========================
def clean_text(text):
    return (text or "").strip()


def is_knowledge_question(text):
    t = clean_text(text).lower()
    starters = (
        "what is",
        "who is",
        "where is",
        "when is",
        "why",
        "how",
        "define",
        "explain",
        "history of",
        "tell me about",
    )
    return t.startswith(starters)


def wants_detailed_answer(text):
    t = clean_text(text).lower()
    return any(word in t for word in ["explain", "detail", "brief", "briefly", "elaborate", "in detail"])


def mood_support_answer(text):
    t = clean_text(text).lower()
    mood_words = [
        "sad",
        "upset",
        "stress",
        "stressed",
        "tension",
        "lonely",
        "alone",
        "bad mood",
        "depressed",
        "cry",
        "edusthunna",
        "badha",
        "bhayam",
        "kopam",
        "naku badha",
        "nenu lonely",
        "mood off",
    ]

    if not any(word in t for word in mood_words):
        return None

    return (
        "I am here with you.\n"
        "1. First, take a slow breath. You do not have to handle everything at once.\n"
        "2. Tell me what happened in one or two lines. I will listen.\n"
        "3. If you want, I can help you calm down, think clearly, or just stay and talk for a while."
    )


def greeting_answer(text):
    t = clean_text(text).lower()
    greetings = {"hi", "hii", "hiii", "hello", "hey", "hai", "helo"}
    if t in greetings:
        return "Hi, I am Aashu, your partner.\nWhat can I do for you?"
    return None


def wants_solver_answer(text):
    t = clean_text(text).lower()
    solve_words = [
        "solve",
        "calculate",
        "find",
        "answer",
        "solution",
        "value",
        "how much",
        "next",
        "entha",
    ]
    return wants_formula_only(t) or bool(numbers(t)) or any(word in t for word in solve_words)


def numbers(text):
    return [float(n) for n in re.findall(r"-?\d+(?:\.\d+)?", text or "")]


def fmt(value):
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return f"{value:.2f}".rstrip("0").rstrip(".")


def formula_response(title, formula, steps, answer):
    lines = [title, f"1. Formula: {formula}"]
    for index, step in enumerate(steps, start=2):
        lines.append(f"{index}. {step}")
    lines.append(f"Answer: {answer}")
    return "\n".join(lines)


SAFE_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def safe_eval_expression(expression):
    def eval_node(node):
        if isinstance(node, ast.Expression):
            return eval_node(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in SAFE_OPERATORS:
            left = eval_node(node.left)
            right = eval_node(node.right)
            return SAFE_OPERATORS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in SAFE_OPERATORS:
            return SAFE_OPERATORS[type(node.op)](eval_node(node.operand))
        raise ValueError("Unsupported expression")

    tree = ast.parse(expression, mode="eval")
    return eval_node(tree)


def solve_arithmetic(text):
    t = clean_text(text).lower()
    if not t:
        return None

    word_expression = t
    replacements = {
        "plus": "+",
        "minus": "-",
        "multiplied by": "*",
        "multiply by": "*",
        "multiply": "*",
        "times": "*",
        "into": "*",
        "divided by": "/",
        "divide by": "/",
        "divide": "/",
        "modulus": "%",
        "mod": "%",
        "remainder": "%",
    }
    for word, symbol in replacements.items():
        word_expression = word_expression.replace(word, symbol)

    expression_match = re.search(r"[-+*/%().\d\s]+", word_expression)
    if not expression_match:
        return None

    expression = expression_match.group(0).strip()
    if not expression or not re.search(r"\d", expression) or not re.search(r"[+\-*/%]", expression):
        return None

    if not re.fullmatch(r"[-+*/%().\d\s]+", expression):
        return None

    try:
        answer = safe_eval_expression(expression)
    except Exception:
        return None

    return formula_response(
        "Arithmetic Operation",
        "BODMAS / operator precedence",
        [f"Expression = {expression}", "Calculate using standard arithmetic order"],
        fmt(float(answer)) if isinstance(answer, (int, float)) else answer,
    )


def wants_formula_only(text):
    t = text.lower()
    formula_words = ["formula", "formulas", "sutram", "suthram", "only formula"]
    solve_words = ["solve", "calculate", "find", "answer", "solution", "value", "how much", "entha", "answer cheppu"]
    return any(word in t for word in formula_words) and not any(word in t for word in solve_words)


def concept_formula(topic):
    formulas = {
        "percentage": "Percentage\n- x% of y = (x / 100) x y\n- Percentage = (part / whole) x 100\n- Percentage change = ((new - old) / old) x 100",
        "average": "Average\nFormula: Average = sum of observations / number of observations",
        "profit_loss": "Profit and Loss\n- Profit = SP - CP\n- Loss = CP - SP\n- Profit% = (Profit / CP) x 100\n- Loss% = (Loss / CP) x 100",
        "simple_interest": "Simple Interest\nFormula: SI = (P x R x T) / 100\nAmount = P + SI",
        "compound_interest": "Compound Interest\nFormula: Amount = P(1 + R/100)^T\nCI = Amount - P",
        "ratio": "Ratio\nFormula: a:b = a / b\nSimplified ratio = divide both terms by HCF",
        "time_work": "Time and Work\n- One day work = 1 / total days\n- A and B together = (A x B) / (A + B)",
        "speed_distance_time": "Speed, Distance, Time\n- Speed = Distance / Time\n- Distance = Speed x Time\n- Time = Distance / Speed",
        "series": "Number Series\n- Arithmetic series: next = last + common difference\n- Geometric series: next = last x common ratio",
        "number_reasoning": "Number Reasoning\n- Even: number % 2 = 0\n- Odd: number % 2 = 1\n- Prime: divisible only by 1 and itself\n- LCM = (a x b) / HCF",
        "coding_decoding": "Coding-Decoding\nCommon method: add alphabet positions of letters.\nExample: CAT = C(3) + A(1) + T(20) = 24",
        "reasoning": "Reasoning topics I can solve:\n- Coding-Decoding: CAT=30 then DOG=?\n- Number series: 2 4 6 8 next?\n- Letter series: A C E G next?\n- Odd one out: 2, 4, 7, 8\n- Direction sense: north/south/east/west movement\n- Blood relation basics: father's son, mother's daughter",
    }
    return formulas.get(topic)


# =========================
# APTITUDE SOLVERS
# =========================
def solve_percentage(text):
    t = text.lower()
    if wants_formula_only(t):
        return concept_formula("percentage")

    nums = numbers(text)

    if len(nums) < 2:
        return None

    repeated_change_match = re.search(
        r"(?:increase|increases|increased|growth|grows|grew|rise|rises)\s+by\s+(\d+(?:\.\d+)?)\s*%.*?(?:every|per|each)\s+year.*?(?:after|for|in)\s+(\d+(?:\.\d+)?)\s+years?",
        t,
    )
    if repeated_change_match:
        rate = float(repeated_change_match.group(1))
        years = float(repeated_change_match.group(2))
        final_value = 100 * ((1 + rate / 100) ** years)
        change = final_value - 100

        return formula_response(
            "Compound Percentage Increase",
            "Final value = Original value x growth multiplier for each year",
            [
                "Assume original value = 100",
                f"Rate = {fmt(rate)}%",
                f"Time = {fmt(years)} years",
                f"Growth multiplier = 1 + {fmt(rate)}/100 = {fmt(1 + rate / 100)}",
                f"Final value = 100 x {fmt(1 + rate / 100)} used {fmt(years)} times = {fmt(final_value)}",
                f"Increase = {fmt(final_value)} - 100 = {fmt(change)}",
            ],
            f"{fmt(change)}% increase",
        )

    successive_match = re.search(
        r"(?:increase|increases|increased|rise|rises|raised)\s+by\s+(\d+(?:\.\d+)?)\s*%.*?(?:decrease|decreases|decreased|fall|falls|reduced)\s+by\s+(\d+(?:\.\d+)?)\s*%",
        t,
    )
    if successive_match:
        inc = float(successive_match.group(1))
        dec = float(successive_match.group(2))
        final_value = 100 * (1 + inc / 100) * (1 - dec / 100)
        change = final_value - 100
        label = "increase" if change > 0 else "decrease" if change < 0 else "no change"

        return formula_response(
            "Successive Percentage Change",
            "Apply each percentage one after another on the latest value",
            [
                "Assume original value = 100",
                f"After {fmt(inc)}% increase = {fmt(100 * (1 + inc / 100))}",
                f"After {fmt(dec)}% decrease = {fmt(final_value)}",
                f"Net change = {fmt(final_value)} - 100 = {fmt(change)}",
            ],
            f"{fmt(abs(change))}% {label}",
        )

    a, b = nums[0], nums[1]

    if re.search(r"what\s+percent|percentage\s+of|percent\s+is|is\s+what\s+percent", t):
        ans = (a / b) * 100
        return formula_response(
            "Percentage",
            "Percentage = Part divided by Whole, then multiply by 100",
            [f"Part = {fmt(a)}", f"Whole = {fmt(b)}", f"({fmt(a)} / {fmt(b)}) x 100 = {fmt(ans)}%"],
            f"{fmt(ans)}%",
        )

    if "increase" in t or "decrease" in t or "change" in t:
        diff = b - a
        ans = (diff / a) * 100 if a else 0
        label = "increase" if diff >= 0 else "decrease"
        return formula_response(
            "Percentage Change",
            "Percentage change = Change divided by Old value, then multiply by 100",
            [f"Old value = {fmt(a)}", f"New value = {fmt(b)}", f"Change = {fmt(diff)}"],
            f"{fmt(abs(ans))}% {label}",
        )

    if re.search(r"\d+(?:\.\d+)?\s*%\s*(?:of)?\s*\d+(?:\.\d+)?|percent\s+of", t):
        ans = (a / 100) * b
        return formula_response(
            "Percentage",
            "Required value = Percent divided by 100, then multiply by given value",
            [f"Percent = {fmt(a)}", f"Value = {fmt(b)}", f"({fmt(a)} / 100) x {fmt(b)} = {fmt(ans)}"],
            fmt(ans),
        )

    return None


def is_plain_average_question(text):
    t = text.lower()
    return bool(re.search(r"(find|calculate)?\s*(the\s+)?average\s+(of\s+)?[-,\s\d.]+$", t))


def is_plain_number_list(text):
    return bool(re.fullmatch(r"\s*-?\d+(?:\.\d+)?(?:\s*,?\s*-?\d+(?:\.\d+)?){1,}\s*", text))


def is_simple_topic_problem(text, topic_words):
    t = text.lower()
    topic_found = any(
        re.search(r"\bcp\b", t) if word == "cp" else re.search(r"\bsp\b", t) if word == "sp" else word in t
        for word in topic_words
    )
    return topic_found and len(numbers(t)) >= 2 and not any(
        word in t
        for word in [
            "after",
            "before",
            "then",
            "respectively",
            "remaining",
            "excluded",
            "included",
            "discount",
            "successive",
            "combined",
        ]
    )


def solve_average(text):
    t = text.lower()
    excluded_match = re.search(
        r"average\s+of\s+(\d+(?:\.\d+)?)\s+numbers?\s+is\s+(\d+(?:\.\d+)?).*?(?:one\s+number\s+is\s+excluded|number\s+is\s+excluded|excluded).*?average\s+becomes\s+(\d+(?:\.\d+)?)",
        t,
    )
    if excluded_match:
        count = float(excluded_match.group(1))
        old_average = float(excluded_match.group(2))
        new_average = float(excluded_match.group(3))
        old_total = count * old_average
        new_total = (count - 1) * new_average
        excluded = old_total - new_total

        return formula_response(
            "Average",
            "excluded number = old total - new total",
            [
                f"Old total = {fmt(count)} x {fmt(old_average)} = {fmt(old_total)}",
                f"New total = ({fmt(count)} - 1) x {fmt(new_average)} = {fmt(new_total)}",
                f"Excluded number = {fmt(old_total)} - {fmt(new_total)}",
            ],
            fmt(excluded),
        )

    if wants_formula_only(text):
        return concept_formula("average")

    nums = numbers(text)
    if not nums:
        return None

    if not (is_plain_average_question(text) or is_plain_number_list(text)):
        return None

    total = sum(nums)
    avg = total / len(nums)
    return formula_response(
        "Average",
        "sum / count",
        [f"Numbers = {', '.join(fmt(n) for n in nums)}", f"Sum = {fmt(total)}", f"Count = {len(nums)}"],
        fmt(avg),
    )


def solve_profit_loss(text):
    t = text.lower()
    if wants_formula_only(t):
        return concept_formula("profit_loss")

    nums = numbers(text)

    if len(nums) < 2:
        return None

    if not is_simple_topic_problem(t, ["profit", "loss", "cp", "sp", "cost price", "selling price"]):
        return None

    cp, sp = nums[0], nums[1]
    diff = sp - cp
    percent = abs(diff) / cp * 100 if cp else 0
    result = "Profit" if diff >= 0 else "Loss"

    return formula_response(
        "Profit and Loss",
        "SP - CP",
        [f"CP = {fmt(cp)}", f"SP = {fmt(sp)}", f"SP - CP = {fmt(diff)}"],
        f"{result} = {fmt(abs(diff))}, {result}% = {fmt(percent)}%",
    )


def solve_simple_interest(text):
    if wants_formula_only(text):
        return concept_formula("simple_interest")

    nums = numbers(text)
    if len(nums) < 3:
        return None

    p, r, t = nums[0], nums[1], nums[2]
    si = (p * r * t) / 100
    amount = p + si
    return formula_response(
        "Simple Interest",
        "(P x R x T) / 100",
        [f"P = {fmt(p)}", f"R = {fmt(r)}", f"T = {fmt(t)}", f"SI = ({fmt(p)} x {fmt(r)} x {fmt(t)}) / 100"],
        f"SI = {fmt(si)}, Amount = {fmt(amount)}",
    )


def solve_compound_interest(text):
    if wants_formula_only(text):
        return concept_formula("compound_interest")

    nums = numbers(text)
    if len(nums) < 3:
        return None

    p, r, t = nums[0], nums[1], nums[2]
    amount = p * ((1 + r / 100) ** t)
    ci = amount - p
    return formula_response(
        "Compound Interest",
        "Amount = P(1 + R/100)^T",
        [f"P = {fmt(p)}", f"R = {fmt(r)}", f"T = {fmt(t)}"],
        f"CI = {fmt(ci)}, Amount = {fmt(amount)}",
    )


def solve_ratio(text):
    if wants_formula_only(text):
        return concept_formula("ratio")

    nums = numbers(text)
    if len(nums) < 2:
        return None

    a, b = int(nums[0]), int(nums[1])
    hcf = math.gcd(a, b)
    return formula_response(
        "Ratio",
        "divide both terms by HCF",
        [f"HCF of {a} and {b} = {hcf}", f"{a}:{b} = {a // hcf}:{b // hcf}"],
        f"{a // hcf}:{b // hcf}",
    )


def solve_time_work(text):
    t = text.lower()
    if wants_formula_only(text):
        return concept_formula("time_work")

    nums = numbers(text)
    if len(nums) < 2:
        return None

    if not any(word in t for word in ["together", "both", "a and b", "two people", "working together"]):
        return None

    a, b = nums[0], nums[1]
    days = (a * b) / (a + b)
    return formula_response(
        "Time and Work",
        "(A x B) / (A + B)",
        [f"A alone = {fmt(a)} days", f"B alone = {fmt(b)} days", f"Together = ({fmt(a)} x {fmt(b)}) / ({fmt(a)} + {fmt(b)})"],
        f"{fmt(days)} days",
    )


def solve_speed_distance_time(text):
    t = text.lower()
    if wants_formula_only(t):
        return concept_formula("speed_distance_time")

    nums = numbers(text)

    if len(nums) < 2:
        return None

    a, b = nums[0], nums[1]

    asks_time = re.search(r"(find|calculate|what is|how much|time taken).*time|time\?", t)
    asks_distance = re.search(r"(find|calculate|what is|how much).*distance|distance\?", t)

    if asks_time:
        ans = a / b
        return formula_response("Time", "distance / speed", [f"Distance = {fmt(a)}", f"Speed = {fmt(b)}"], fmt(ans))

    if asks_distance:
        ans = a * b
        return formula_response("Distance", "speed x time", [f"Speed = {fmt(a)}", f"Time = {fmt(b)}"], fmt(ans))

    if "speed" not in t:
        return None

    ans = a / b
    return formula_response("Speed", "distance / time", [f"Distance = {fmt(a)}", f"Time = {fmt(b)}"], fmt(ans))


# =========================
# REASONING SOLVERS
# =========================
def solve_number_reasoning(text):
    t = text.lower()
    if wants_formula_only(t) and any(word in t for word in ["number", "even", "odd", "prime", "hcf", "gcd", "lcm"]):
        return concept_formula("number_reasoning")

    nums = numbers(text)
    ints = [int(n) for n in nums]

    if ("even" in t or "odd" in t) and ints:
        n = ints[0]
        return formula_response("Even or Odd", "number % 2", [f"{n} % 2 = {n % 2}"], f"{n} is {'Even' if n % 2 == 0 else 'Odd'}")

    if "prime" in t and ints:
        n = ints[0]
        if n <= 1:
            return f"Prime Number\nAnswer: {n} is not prime because prime numbers are greater than 1."
        limit = int(math.sqrt(n))
        factors = [i for i in range(2, limit + 1) if n % i == 0]
        answer = "Prime" if not factors else f"Not prime, divisible by {factors[0]}"
        return formula_response("Prime Number", "check divisibility from 2 to sqrt(n)", [f"sqrt({n}) = {limit}"], f"{n} is {answer}")

    if ("hcf" in t or "gcd" in t) and len(ints) >= 2:
        result = math.gcd(ints[0], ints[1])
        return formula_response("HCF/GCD", "greatest common factor", [f"Numbers = {ints[0]}, {ints[1]}"], result)

    if "lcm" in t and len(ints) >= 2:
        result = abs(ints[0] * ints[1]) // math.gcd(ints[0], ints[1])
        return formula_response("LCM", "(a x b) / HCF", [f"HCF = {math.gcd(ints[0], ints[1])}"], result)

    return None


def solve_series(text):
    t = text.lower()
    nums = [int(n) for n in re.findall(r"-?\d+", text)]
    only_number_pattern = re.fullmatch(r"\s*-?\d+(?:\s*,?\s*-?\d+){2,}\s*(?:next)?\??\s*", t)
    is_series_question = "series" in t or "next number" in t or bool(only_number_pattern)

    if not is_series_question:
        return None

    if wants_formula_only(text):
        return concept_formula("series")

    if len(nums) < 3:
        return concept_formula("series")

    diffs = [nums[i + 1] - nums[i] for i in range(len(nums) - 1)]
    if len(set(diffs)) == 1:
        next_num = nums[-1] + diffs[0]
        return formula_response("Arithmetic Series", "next = last + common difference", [f"Common difference = {diffs[0]}"], next_num)

    if all(nums[i] != 0 for i in range(len(nums) - 1)):
        ratios = [nums[i + 1] / nums[i] for i in range(len(nums) - 1)]
        if len(set(ratios)) == 1:
            next_num = int(nums[-1] * ratios[0])
            return formula_response("Geometric Series", "next = last x common ratio", [f"Common ratio = {fmt(ratios[0])}"], next_num)

    return "Number Series\nI can solve arithmetic and geometric series directly. For this pattern, ask like: series 2 4 6 8 or series 3 6 12 24."


def alphabet_sum(word):
    return sum(ord(ch) - 64 for ch in word.upper() if "A" <= ch.upper() <= "Z")


def solve_coding_decoding(text):
    t = text.lower()

    if wants_formula_only(t) and ("coding" in t or "decoding" in t):
        return concept_formula("coding_decoding")

    match = re.search(
        r"\b([a-zA-Z]+)\s*=\s*(-?\d+).*?(?:what\s+is|find|value\s+of|then)?\s*([a-zA-Z]+)\??\s*$",
        text,
        re.IGNORECASE,
    )

    if not match:
        return None

    given_word = match.group(1).upper()
    given_value = int(match.group(2))
    target_word = match.group(3).upper()

    ignored_words = {"WHAT", "IS", "FIND", "VALUE", "OF", "THEN"}
    if target_word in ignored_words:
        return None

    given_sum = alphabet_sum(given_word)
    target_sum = alphabet_sum(target_word)
    difference = given_value - given_sum
    answer = target_sum + difference

    return formula_response(
        "Coding-Decoding",
        "alphabet position sum + same difference",
        [
            f"{given_word} alphabet sum = {given_sum}",
            f"Given {given_word} = {given_value}, so difference = {given_value} - {given_sum} = {difference}",
            f"{target_word} alphabet sum = {target_sum}",
            f"{target_sum} + {difference} = {answer}",
        ],
        answer,
    )


def solve_letter_series(text):
    t = text.lower()
    if wants_formula_only(text) and "letter" in t:
        return "Letter Series\nMethod: convert letters to alphabet positions, find the gap, then apply same gap to the last letter."

    letters = re.findall(r"\b[A-Z]\b", text.upper())
    if len(letters) < 3:
        return None

    values = [ord(ch) - 64 for ch in letters]
    diffs = [values[i + 1] - values[i] for i in range(len(values) - 1)]

    if len(set(diffs)) == 1:
        next_value = values[-1] + diffs[0]
        if 1 <= next_value <= 26:
            next_letter = chr(next_value + 64)
            return formula_response(
                "Letter Series",
                "next letter = last letter position + common gap",
                [
                    f"Letters = {', '.join(letters)}",
                    f"Positions = {values}",
                    f"Common gap = {diffs[0]}",
                ],
                next_letter,
            )

    return None


def solve_odd_one_out(text):
    t = text.lower()
    if "odd one" not in t and "odd man" not in t and "different" not in t:
        return None

    nums = [int(n) for n in re.findall(r"-?\d+", text)]
    if len(nums) >= 3:
        evens = [n for n in nums if n % 2 == 0]
        odds = [n for n in nums if n % 2 != 0]
        if len(evens) == 1:
            return formula_response("Odd One Out", "compare common property", [f"Most numbers are odd, only {evens[0]} is even"], evens[0])
        if len(odds) == 1:
            return formula_response("Odd One Out", "compare common property", [f"Most numbers are even, only {odds[0]} is odd"], odds[0])

    words = re.findall(r"\b[a-zA-Z]+\b", text)
    skip = {"odd", "one", "out", "find", "which", "is", "different", "man"}
    words = [w for w in words if w.lower() not in skip]
    if len(words) >= 3:
        lengths = {}
        for word in words:
            lengths.setdefault(len(word), []).append(word)
        single_lengths = [items[0] for items in lengths.values() if len(items) == 1]
        if len(single_lengths) == 1:
            return formula_response("Odd One Out", "compare common property", [f"Only {single_lengths[0]} has a different word length"], single_lengths[0])

    return "Odd One Out\nI can solve simple number parity and word-length odd-one-out. Example: odd one out 2 4 7 8."


def solve_direction_sense(text):
    t = text.lower()
    if not any(word in t for word in ["north", "south", "east", "west", "direction"]):
        return None

    x, y = 0, 0
    moves = re.findall(r"(\d+(?:\.\d+)?)\s*(?:km|kilometer|kilometers|m|meter|meters)?\s*(north|south|east|west)", t)
    for value, direction in moves:
        distance = float(value)
        if direction == "north":
            y += distance
        elif direction == "south":
            y -= distance
        elif direction == "east":
            x += distance
        elif direction == "west":
            x -= distance

    if not moves:
        return None

    horizontal = "east" if x > 0 else "west" if x < 0 else ""
    vertical = "north" if y > 0 else "south" if y < 0 else ""
    distance = math.sqrt((x * x) + (y * y))

    if vertical and horizontal:
        direction = f"{vertical}-{horizontal}"
    elif vertical:
        direction = vertical
    elif horizontal:
        direction = horizontal
    else:
        direction = "same starting point"

    return formula_response(
        "Direction Sense",
        "net east-west and north-south movement",
        [f"Net east/west = {fmt(x)}", f"Net north/south = {fmt(y)}"],
        f"{fmt(distance)} units towards {direction}",
    )


def solve_blood_relation(text):
    t = text.lower()
    if not any(word in t for word in ["father", "mother", "son", "daughter", "brother", "sister", "husband", "wife", "blood relation", "relation"]):
        return None

    normalized = t.replace("’", "'")
    normalized = re.sub(r"\bmy\b|\bme\b|\bperson\b|\bthe\b|\brelation\b|\bwho is\b|\bwhat is\b|\bhow is\b|\bto me\b|\bof\b", " ", normalized)
    relation_words = re.findall(r"father|mother|son|daughter|brother|sister|husband|wife", normalized)

    of_my_match = re.search(
        r"\b(father|mother|son|daughter|brother|sister|husband|wife)\s+of\s+my\s+(father|mother|son|daughter|brother|sister|husband|wife)\b",
        t,
    )
    if of_my_match:
        relation_words = [of_my_match.group(2), of_my_match.group(1)]

    if not relation_words:
        return None

    phrase = " ".join(relation_words)
    relation_map = {
        "father": "father",
        "mother": "mother",
        "brother": "brother",
        "sister": "sister",
        "son": "son",
        "daughter": "daughter",
        "husband": "husband",
        "wife": "wife",
        "father father": "grandfather",
        "mother father": "grandfather",
        "father mother": "grandmother",
        "mother mother": "grandmother",
        "father brother": "uncle",
        "mother brother": "uncle",
        "father sister": "aunt",
        "mother sister": "aunt",
        "brother son": "nephew",
        "sister son": "nephew",
        "brother daughter": "niece",
        "sister daughter": "niece",
        "son son": "grandson",
        "daughter son": "grandson",
        "son daughter": "granddaughter",
        "daughter daughter": "granddaughter",
        "husband father": "father-in-law",
        "wife father": "father-in-law",
        "husband mother": "mother-in-law",
        "wife mother": "mother-in-law",
        "father son": "brother or myself",
        "mother son": "brother or myself",
        "father daughter": "sister or myself",
        "mother daughter": "sister or myself",
        "father brother son": "cousin",
        "father sister son": "cousin",
        "mother brother son": "cousin",
        "mother sister son": "cousin",
        "father brother daughter": "cousin",
        "father sister daughter": "cousin",
        "mother brother daughter": "cousin",
        "mother sister daughter": "cousin",
    }

    answer = relation_map.get(phrase)

    if not answer:
        return None

    steps = [f"Relation chain = {' -> '.join(relation_words)}"]
    if len(relation_words) >= 2:
        steps.append(f"Matched pattern = {phrase}")

    return formula_response("Blood Relation", "decode relation from left to right", steps, answer)


def solve_reasoning(text):
    if wants_formula_only(text) and "reasoning" in text.lower():
        return concept_formula("reasoning")

    for solver in [
        solve_coding_decoding,
        solve_letter_series,
        solve_series,
        solve_odd_one_out,
        solve_direction_sense,
        solve_blood_relation,
        solve_number_reasoning,
    ]:
        ans = solver(text)
        if ans:
            return ans

    if "reasoning" in text.lower():
        return concept_formula("reasoning")

    return None


# =========================
# MAIN CONCEPT SOLVER
# =========================
def solve_concept(text):
    t = clean_text(text).lower()

    if not t:
        return None

    arithmetic = solve_arithmetic(text)
    if arithmetic:
        return arithmetic

    if ("formula" in t or "formulas" in t) and "aptitude" in t:
        return (
            "Aptitude formulas I can help with:\n"
            "- Percentage: (part / whole) x 100\n"
            "- Average: sum / count\n"
            "- Profit/Loss: SP - CP\n"
            "- SI: (P x R x T) / 100\n"
            "- CI: P(1 + R/100)^T - P\n"
            "- Time and Work: (A x B) / (A + B)\n"
            "- Speed: distance / time\n"
            "- Ratio: simplify using HCF\n"
            "- LCM: (a x b) / HCF"
        )
    if ("percentage" in t or "percent" in t or "%" in t) and wants_solver_answer(t):
        return solve_percentage(t)
    if ("average" in t or "mean" in t) and wants_solver_answer(t):
        return solve_average(t)
    if ("profit" in t or "loss" in t or re.search(r"\bcp\b", t) or re.search(r"\bsp\b", t)) and wants_solver_answer(t):
        return solve_profit_loss(t)
    if ("simple interest" in t or re.search(r"\bsi\b", t)) and wants_solver_answer(t):
        return solve_simple_interest(t)
    if ("compound interest" in t or re.search(r"\bci\b", t)) and wants_solver_answer(t):
        return solve_compound_interest(t)
    if "ratio" in t and wants_solver_answer(t):
        return solve_ratio(t)
    if "work" in t and wants_solver_answer(t):
        return solve_time_work(t)
    if ("speed" in t or "distance" in t) and wants_solver_answer(t):
        return solve_speed_distance_time(t)
    reasoning = solve_reasoning(text)
    if reasoning:
        return reasoning
    return None


# =========================
# MEMORY
# =========================
def memory_answer(user, allow_fuzzy=True):
    key = clean_text(user).lower()

    if key in memory:
        return memory[key]

    if not allow_fuzzy or is_knowledge_question(key):
        return None

    match = difflib.get_close_matches(key, memory.keys(), n=1, cutoff=0.7)
    if match:
        return memory[match[0]]

    return None


# =========================
# AI
# =========================
def ai_answer(text):
    global session_started

    if not models:
        return "AI is not configured. Please set GEMINI_API_KEY."

    if wants_formula_only(text):
        answer_rule = "The user asked only for a formula. Give only the relevant formula. Do not solve an example."
    else:
        line_limit = "5 to 7 bullet points" if wants_detailed_answer(text) else "2 to 4 bullet points"
        answer_rule = (
            "Answer exactly what the user asks, no extra unrelated information. Use clear numbered points. "
            "Use simple words. Avoid special math symbols when plain words are easier. "
            f"For general questions, answer in {line_limit}. "
            "For aptitude or reasoning problems, use this format: Formula, Steps, Final answer. "
            "Put every step on a new numbered line. "
            "If the question is unclear, ask one short clarification instead of guessing."
        )

    if session_started:
        intro_rule = """
Do not introduce yourself.
Do not greet the user.
Do not say "Hello", "Hi", "I am Aashu", or "Here are".
Start directly with the relevant answer.
"""
    else:
        intro_rule = """
This is the first AI answer in this chat. You may briefly introduce yourself as Aashu only if it feels natural.
Keep the intro to one short line, then answer the question.
Do not ask what the user wants to study.
Do not ask follow-up questions unless the user's question is unclear.
"""

    prompt = f"""
You are Aashu, a study assistant.
{intro_rule}
Rules:
- {answer_rule}
- Keep it short, clear, and numbered.
- No unrelated lines.
Question: {text}
"""

    last_error = None
    for active_model in models:
        try:
            res = active_model.generate_content(prompt)
            if res and hasattr(res, "text") and res.text:
                session_started = True
                return res.text
        except Exception as exc:
            last_error = exc

    if last_error:
        return f"AI error: {type(last_error).__name__}. Please check Gemini API key/model/network."

    return None


# =========================
# ROUTES
# =========================
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/get")
def get_response():
    user = clean_text(request.args.get("msg"))

    if not user:
        return "Please type a question."

    greeting = greeting_answer(user)
    if greeting:
        return greeting

    mem = memory_answer(user, allow_fuzzy=False)
    if mem:
        return mem

    mood = mood_support_answer(user)
    if mood:
        return mood

    ans = solve_concept(user)
    if ans:
        return ans

    ai = ai_answer(user)
    if ai:
        return ai

    return "I do not know this yet. Teach me the answer and I will remember it."


@app.route("/teach")
def teach():
    user = clean_text(request.args.get("user"))
    reply = clean_text(request.args.get("reply"))

    if not user or not reply:
        return "Please give both the question and the answer."

    memory[user.lower()] = reply
    save_memory()
    return "Got it. I will remember this answer."


# =========================
# RUN
# =========================
if __name__ == "__main__":
    app.run(debug=True)
